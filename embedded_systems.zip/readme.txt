The project is using the Arduino uno board to make a smart traffic light system.
https://www.youtube.com/watch?v=gpH7jlithLg