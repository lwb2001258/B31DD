from django.apps import AppConfig


class SettingTraficStatusConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'setting_trafic_status'
