The project should work with the arduino traffic lights system. After the traffic light systems working, run the script communicate_with_board.py in the others directory.
Then run the command in the console python manage.py runserver at the project directory. The visit the url http://127.0.0.1:8000/light_status/ through the web browser.
